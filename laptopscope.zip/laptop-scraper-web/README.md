# 🖥️ LaptopScope — Live Laptop Price Tracker

A full-stack web app that scrapes **Best Buy**, **Newegg**, and **NotebookCheck**
for real-time laptop prices, specs, and benchmarks. Dark-themed, animated UI.
100% free — no API key needed.

---

## 🚀 Run on GitHub Codespaces (iPad friendly!)

### Step 1 — Upload to GitHub
1. Go to [github.com](https://github.com) → sign in or create a free account
2. Click **+** → **New repository** → name it `laptopscope` → **Private** → **Create**
3. Upload ALL files keeping the folder structure:
   ```
   app.py
   requirements.txt
   .devcontainer/devcontainer.json
   templates/index.html
   ```

### Step 2 — Open Codespaces
1. On your repo, click green **Code** button → **Codespaces** tab
2. Click **Create codespace on main**
3. Wait ~90 seconds — it auto-installs Flask and everything

### Step 3 — Run the app
In the terminal at the bottom:
```bash
python app.py
```

Codespaces will **automatically pop open a browser** with the app running!
If it doesn't, click the **Ports** tab and click the 🌐 globe icon next to port 5000.

---

## 🎮 How to Use

1. **Type** what you're looking for in the search bar
2. **Set a budget** in dollars (optional)
3. **Toggle sources** — Best Buy, Newegg, NotebookCheck
4. Hit **Search** — results load with live prices and specs
5. Click any card to open the product page

### Preset buttons (quick searches):
- RTX 5060 Under $1100
- RTX 4060 Budget
- Lenovo Legion 5
- ASUS TUF Gaming
- 165Hz Displays

---

## 📁 File Structure

```
laptopscope/
├── app.py                    ← Flask backend (all scraping logic)
├── requirements.txt          ← Python packages
├── .devcontainer/
│   └── devcontainer.json    ← Codespaces auto-setup
└── templates/
    └── index.html           ← Full animated frontend
```

---

## 🔧 Customize Searches

Edit the presets in `app.py` → `/api/presets` route:

```python
{"label": "My Custom Search", "query": "your search here", "budget": 1000},
```

---

## ❓ Troubleshooting

**App won't open** → Make sure you ran `python app.py` in the terminal

**0 results** → A site may have temporarily rate-limited the scraper.
Wait 2–3 minutes and try again.

**ModuleNotFoundError** → Run `pip install -r requirements.txt` first

**Prices seem off** → Always verify on the actual site — prices update constantly!
