"""
Laptop Scraper — Flask Backend
Run: python app.py
Then open: http://localhost:5000
"""

from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import json
import time
import re
from datetime import datetime
import threading

app = Flask(__name__)
CORS(app)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# ── Scrapers ─────────────────────────────────────────────────────────────────

def search_bestbuy(query: str) -> list:
    results = []
    url = "https://www.bestbuy.com/site/searchpage.jsp"
    params = {"st": query, "cp": 1}
    try:
        r = requests.get(url, params=params, headers=HEADERS, timeout=12)
        soup = BeautifulSoup(r.text, "html.parser")
        items = soup.select("li.sku-item")[:10]
        for item in items:
            name_el = item.select_one(".sku-title a")
            price_el = item.select_one("[data-testid='customer-price'] span[aria-hidden='true']")
            rating_el = item.select_one(".c-ratings-reviews .visually-hidden")
            img_el = item.select_one(".product-image img")

            if name_el and price_el:
                price_str = price_el.text.strip()
                price_num = parse_price(price_str)
                results.append({
                    "source": "Best Buy",
                    "source_color": "#003da5",
                    "name": name_el.text.strip(),
                    "price": price_str,
                    "price_num": price_num,
                    "rating": rating_el.text.strip() if rating_el else None,
                    "url": "https://www.bestbuy.com" + name_el.get("href", ""),
                    "image": img_el.get("src") if img_el else None,
                    "specs": extract_specs(name_el.text.strip()),
                })
    except Exception as e:
        print(f"BestBuy error: {e}")
    return results


def search_newegg(query: str) -> list:
    results = []
    url = "https://www.newegg.com/p/pl"
    params = {"d": query, "N": "4131"}
    try:
        r = requests.get(url, params=params, headers=HEADERS, timeout=12)
        soup = BeautifulSoup(r.text, "html.parser")
        items = soup.select(".item-cell")[:10]
        for item in items:
            name_el = item.select_one(".item-title")
            price_el = item.select_one(".price-current strong")
            price_sup = item.select_one(".price-current sup")
            img_el = item.select_one(".item-img img")

            if name_el and price_el:
                cents = price_sup.text.strip() if price_sup else "00"
                price_str = f"${price_el.text.strip().replace(',','')}.{cents}"
                price_num = parse_price(price_str)
                results.append({
                    "source": "Newegg",
                    "source_color": "#e2720c",
                    "name": name_el.text.strip(),
                    "price": price_str,
                    "price_num": price_num,
                    "rating": None,
                    "url": name_el.get("href", "#"),
                    "image": img_el.get("src") if img_el else None,
                    "specs": extract_specs(name_el.text.strip()),
                })
    except Exception as e:
        print(f"Newegg error: {e}")
    return results


def search_notebookcheck(query: str) -> list:
    results = []
    url = "https://www.notebookcheck.net/Search.html"
    params = {"s": query}
    try:
        r = requests.get(url, params=params, headers=HEADERS, timeout=12)
        soup = BeautifulSoup(r.text, "html.parser")
        items = soup.select(".search_results article")[:6]
        for item in items:
            title_el = item.select_one("h2 a")
            desc_el = item.select_one("p")
            date_el = item.select_one("time")
            if title_el:
                results.append({
                    "source": "NotebookCheck",
                    "source_color": "#2ecc71",
                    "name": title_el.text.strip(),
                    "price": "Review",
                    "price_num": None,
                    "rating": None,
                    "url": "https://www.notebookcheck.net" + title_el.get("href", ""),
                    "image": None,
                    "description": desc_el.text.strip()[:200] if desc_el else "",
                    "date": date_el.text.strip() if date_el else "",
                    "specs": {},
                })
    except Exception as e:
        print(f"NotebookCheck error: {e}")
    return results


# ── Helpers ───────────────────────────────────────────────────────────────────

def parse_price(price_str: str) -> float | None:
    match = re.search(r"[\d,]+\.?\d*", price_str.replace(",", ""))
    if match:
        try:
            return float(match.group(0))
        except:
            pass
    return None


def extract_specs(name: str) -> dict:
    specs = {}
    gpu = re.search(r"RTX\s*\d{4}\s*(?:Ti)?|GTX\s*\d{4}", name, re.I)
    if gpu:
        specs["GPU"] = gpu.group(0).strip()
    ram = re.search(r"\d+\s*GB\s*(?:DDR\d|RAM|Memory|LPDDR\d)", name, re.I)
    if ram:
        specs["RAM"] = ram.group(0).strip()
    cpu_patterns = [r"Core\s*(?:Ultra\s*)?\w+[-\s]\d+\w*", r"Ryzen\s*\d\s*\d{4}\w*", r"i[357]-\d{4,5}\w*"]
    for pat in cpu_patterns:
        m = re.search(pat, name, re.I)
        if m:
            specs["CPU"] = m.group(0).strip()
            break
    storage = re.search(r"\d+(?:\.\d+)?\s*(?:TB|GB)\s*(?:SSD|NVMe|PCIe)", name, re.I)
    if storage:
        specs["Storage"] = storage.group(0).strip()
    hz = re.search(r"(\d+)\s*Hz", name, re.I)
    if hz:
        specs["Display"] = hz.group(1) + "Hz"
    return specs


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/search")
def api_search():
    query = request.args.get("q", "RTX 5060 laptop")
    budget = request.args.get("budget", type=float)
    sources = request.args.getlist("sources") or ["bestbuy", "newegg", "notebookcheck"]
    sort_by = request.args.get("sort", "price")

    all_results = []

    if "bestbuy" in sources:
        all_results.extend(search_bestbuy(query))
        time.sleep(0.5)
    if "newegg" in sources:
        all_results.extend(search_newegg(query))
        time.sleep(0.5)
    if "notebookcheck" in sources:
        all_results.extend(search_notebookcheck(query))

    # Filter by budget
    if budget:
        all_results = [
            r for r in all_results
            if r["price_num"] is None or r["price_num"] <= budget
        ]

    # Sort
    if sort_by == "price":
        all_results.sort(key=lambda x: (x["price_num"] is None, x["price_num"] or 0))
    elif sort_by == "name":
        all_results.sort(key=lambda x: x["name"])

    return jsonify({
        "results": all_results,
        "count": len(all_results),
        "query": query,
        "timestamp": datetime.now().isoformat(),
    })


@app.route("/api/presets")
def presets():
    return jsonify([
        {"label": "RTX 5060 Under $1100", "query": "RTX 5060 gaming laptop 32GB", "budget": 1100},
        {"label": "RTX 4060 Budget", "query": "RTX 4060 gaming laptop 16GB", "budget": 850},
        {"label": "Lenovo Legion 5", "query": "Lenovo Legion 5 RTX 5060", "budget": 1200},
        {"label": "ASUS TUF Gaming", "query": "ASUS TUF gaming laptop RTX", "budget": 1000},
        {"label": "165Hz Displays", "query": "gaming laptop 165Hz RTX 5060", "budget": 1100},
    ])


if __name__ == "__main__":
    app.run(debug=True, port=5000)
